function randomValues() {
    anime({
        targets: '#logo',
        translateX: function() {
            return anime.random(0, 50);
        },
        easing: 'easeInOutQuad',
        duration: 750,
        complete: randomValues
    });
}

randomValues();
var colorsExamples = anime.timeline({
        endDelay: 200,
        easing: 'easeInOutQuad',
        direction: 'alternate',
        loop: true
    })
    .add({ targets: '#presentAni', Color: 'rgba(142,145,16, .2)' }, 0)
    .add({ targets: '#presentAni', translateY: 50 }, 0);